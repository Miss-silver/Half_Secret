package com.example.half_secret;
//import java.util.regex.Pattern;

import android.os.Bundle;
import android.app.Activity;
//import android.text.Editable;
//import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {

    EditText editText_suiji;
    EditText editText_mingwen;
    Button btn_answer,btn_qingkong;
    TextView textView_mima;
    private Half_Secret_Service half_Secret_Service;
    private String Str_answer; //���ص�
	protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
       
        initView();
	    initEvent1();
	    initEvent();
	    half_Secret_Service = new Half_Secret_Service();
	}
	//�����¼�
	private void initEvent() {
	
		btn_qingkong.setOnClickListener(new qingkongListener());
	}
	private void initEvent1() {
		btn_answer.setOnClickListener(new answerListener());
	}
	private void initView() {
		editText_suiji = (EditText) findViewById(R.id.edit_shuru); //���������
		editText_mingwen = (EditText) findViewById(R.id.edit_mingwen);
		btn_qingkong = (Button) findViewById(R.id.qingkong);
		btn_answer= (Button) findViewById(R.id.mima_text);
		textView_mima = (TextView) findViewById(R.id.show_mima);
	}
	
void showMima(){
		Str_answer = half_Secret_Service.getAnswer();
		textView_mima.setText(Str_answer.substring(5, 10));
	}
	//
	class answerListener implements OnClickListener{

		String suiji = null;
	    String mingwen = null;
		public void onClick(View arg0) {
			suiji = editText_suiji.getText().toString();
			mingwen = editText_mingwen.getText().toString();
			//String regEx="[A-Z,a-z,0-9]";
			if(suiji.equals("")||mingwen.equals("")){
				Toast.makeText(MainActivity.this, "û������", Toast.LENGTH_SHORT).show();
			}else if(shaixuan(mingwen)&&shaixuan(suiji)){
				half_Secret_Service.half_Secert_Service(suiji, mingwen);
				showMima();
			}else{
				Toast.makeText(MainActivity.this, "�Ƿ�����", Toast.LENGTH_SHORT).show();
				editText_suiji.setText("");
				editText_mingwen.setText("");
				textView_mima.setText("");
			}
		}
		
	}
	
   
    class qingkongListener implements OnClickListener{

		public void onClick(View arg0) {
			editText_suiji.setText("");
			editText_mingwen.setText("");
			textView_mima.setText("");
		}
    }
    
    private boolean shaixuan(String str){
    	char []ch=str.toCharArray();
    	int biaoji=1;
    	boolean jieguo = false;
    	for(int i=0;i<str.length();i++){
    		if(((ch[i]<='Z'&&ch[i]>='A')||(ch[i]<='z'&&ch[i]>='a')||(ch[i]<='9'&&ch[i]>='0'))&&biaoji==ch.length)
    		{
    			jieguo=true;
    		}else if(((ch[i]<='Z'&&ch[i]>='A')||(ch[i]<='z'&&ch[i]>='a')||(ch[i]<='9'&&ch[i]>='0'))&&biaoji<ch.length)
    		{
    			biaoji++;
    		}else{
    			jieguo=false;
    		}
    	}
    	return jieguo;
    }
   
    
}
