package com.example.half_secret;


import java.math.BigInteger;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
//import java.util.*;

class Half_Secret_Service {
    
	private String sm2Encrypted_16;

	public void half_Secert_Service(String str1,String str2){
		try{
			MessageDigest md1=MessageDigest.getInstance("MD5");
			MessageDigest md2=MessageDigest.getInstance("MD5");
			md1.update(str1.getBytes());
			md2.update(str2.getBytes());
			byte b1[]=md1.digest();
			byte b2[]=md2.digest();
			int i;
			StringBuffer buf1=new StringBuffer("");
			StringBuffer buf2=new StringBuffer("");
			for(int offset1=0;offset1<b1.length;offset1++)
			{
				i=(int)b1[offset1];
				if(i<0)
					i+=256;
				if(i<16)
					buf1.append("0");
				buf1.append(Integer.toHexString(i));
			}
			//System.out.println("buf1:"+buf1.toString());
			for(int offset2=0;offset2<b2.length;offset2++)
			{
				i=(int)b2[offset2];
				if(i<0)
					i+=256;
				if(i<16)
					buf2.append("0");
				buf2.append(Integer.toHexString(i));
			}
			String s1=buf1.toString().substring(8, 24);
			String s2=buf2.toString().substring(8, 24);
			BigInteger bigInt1 = new BigInteger(s1,16);  
	        BigInteger bigInt2 = new BigInteger(s2,16);
	        
	        String st1=bigInt1.toString(2);
	        String st2=bigInt2.toString(2);
	        
	        int array1[]=BinstrToIntArray(st1);
	        int array2[]=BinstrToIntArray(st2);
	        
	        int[] resultArray=new int[Math.min(array1.length, array2.length)];
	        
	        for(int j=0;j<resultArray.length;j++)
	        {
	     	   resultArray[j]=array1[j]&array2[j];
	        }
	        
	        
	        StringBuilder sb=new StringBuilder();
	        
	        for(int m=0;m<resultArray.length;m++){
	        	if(m!=resultArray.length)
	        		sb.append(resultArray[m]);
	        }
	        
	        String sm2=sb.toString().substring(0,20);
	        
	        MessageDigest md3=MessageDigest.getInstance("MD5");
	    	md3.update(sm2.getBytes());
	    	
	    	byte b3[]=md3.digest();
	    	
	    	StringBuffer buf3=new StringBuffer("");
	    	//int i;
	    	//int i;
	    	//StringBuffer buf3 = new StringBuffer("");       
	    	for(int offset = 0; offset < b3.length; offset++)
	    	{   
	    		i = (int)b3[offset];    
	    	    if(i<0)     i+= 256;   
	    	    if(i<16)     buf3.append("0");    
	    	    buf3.append(Integer.toHexString(i));   
	    	}
	    	
	    	sm2Encrypted_16=buf3.toString().substring(8,24);
	    	 System.out.print(sm2Encrypted_16);  
			
		}catch (NoSuchAlgorithmException e){};
  }
	        
	 public String getAnswer(){
		 
		 
		return sm2Encrypted_16;
	}
	 
	 private static int[] BinstrToIntArray(String binStr){
			char[] temp =binStr.toCharArray();
			int[] result2=new int[temp.length];
			for(int i=0;i<temp.length;i++)
			{
				result2[i] = temp[i]-48;
			}
			return result2;
		} 
}

